package com.ahang;

import com.ahang.Config.applicationConfig;
import com.ahang.Service.AnnoService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author ahang
 * @date 2021/12/23 21:36
 */
public class TestClass {
    public static void main(String[] args) throws SQLException {
        ApplicationContext app = new AnnotationConfigApplicationContext(applicationConfig.class);
        AnnoService annoService = (AnnoService) app.getBean("annoService");
        annoService.run();

        DataSource dataSource = (DataSource) app.getBean("dataSource");
        Connection connection = dataSource.getConnection();
        System.out.println(connection);
        System.out.println(dataSource);
        connection.close();
    }
}
