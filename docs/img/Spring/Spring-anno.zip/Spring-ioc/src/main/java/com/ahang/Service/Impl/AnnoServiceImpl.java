package com.ahang.Service.Impl;

import com.ahang.Dao.AnnoDao;
import com.ahang.Service.AnnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author ahang
 * @date 2021/12/23 17:12
 */
@Service("annoService")
public class AnnoServiceImpl implements AnnoService {

    @Autowired
    AnnoDao annoDao;

    public AnnoDao getAnnoDao() {
        return annoDao;
    }

    public void setAnnoDao(AnnoDao annoDao) {
        this.annoDao = annoDao;
    }

    @Override
    public void run() {
        annoDao.run();
    }
}
