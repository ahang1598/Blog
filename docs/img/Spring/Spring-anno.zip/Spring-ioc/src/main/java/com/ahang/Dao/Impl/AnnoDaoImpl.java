package com.ahang.Dao.Impl;

import com.ahang.Dao.AnnoDao;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

/**
 * @author ahang
 * @date 2021/12/23 17:10
 */
@Repository("annoDao")
public class AnnoDaoImpl implements AnnoDao {

    @Value("haha")
    String name;

    @Value("${age}")
    int age;

    @Override
    public void run() {

        System.out.println(name + " - "+ age + " anno running..");
    }
}
