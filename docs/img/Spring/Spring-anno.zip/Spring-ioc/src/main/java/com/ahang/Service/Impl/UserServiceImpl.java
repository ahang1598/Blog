package com.ahang.Service.Impl;

import com.ahang.Dao.UserDao;
import com.ahang.Service.UserService;

/**
 * @author ahang
 * @date 2021/12/23 8:54
 */
public class UserServiceImpl implements UserService {

    private UserDao userDao;

    public UserServiceImpl() {
    }

    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public void run() {
        userDao.run();
    }
}
