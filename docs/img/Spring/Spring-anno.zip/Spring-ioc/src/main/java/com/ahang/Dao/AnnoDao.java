package com.ahang.Dao;

/**
 * @author ahang
 * @date 2021/12/23 17:09
 */

public interface AnnoDao {
    public void run();
}
