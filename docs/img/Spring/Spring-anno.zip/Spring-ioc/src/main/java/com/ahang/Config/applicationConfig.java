package com.ahang.Config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * @author ahang
 * @date 2021/12/23 21:20
 */
@Configuration
@ComponentScan("com.ahang")  // 配置扫描
@PropertySource("classpath:student.properties") // 导入properties文件
@Import({JdbcConfig.class}) // 导入其他配置
public class applicationConfig {

}
