package com.ahang.Dao;

/**
 * @author ahang
 * @date 2021/12/23 8:52
 */
public interface UserDao {
    public void run();
}
