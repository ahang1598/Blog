package com.ahang.Service;

/**
 * @author ahang
 * @date 2021/12/23 17:11
 */
public interface AnnoService {
    public void run();
}
