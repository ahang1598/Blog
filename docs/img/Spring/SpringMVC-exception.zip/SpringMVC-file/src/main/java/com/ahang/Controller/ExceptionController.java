package com.ahang.Controller;

import com.ahang.Service.ExceptionDemo;
import com.ahang.Service.MyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.FileNotFoundException;

/**
 * @author ahang
 * @date 2021/12/25 17:02
 */
@Controller
public class ExceptionController {

    @Autowired
    ExceptionDemo exceptionDemo;

    @RequestMapping("/exception")
    public String show() throws FileNotFoundException, MyException {
//        exceptionDemo.show1();
//        exceptionDemo.show2();
//        exceptionDemo.show3(); // 页面上class error
//        exceptionDemo.show4();
        exceptionDemo.show5();
        return "success";
    }


}
