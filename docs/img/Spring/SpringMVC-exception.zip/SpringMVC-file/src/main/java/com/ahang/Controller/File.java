package com.ahang.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * @author ahang
 * @date 2021/12/25 15:22
 */
@Controller
public class File {
    @RequestMapping("/fileJsp")
    public String fileJsp(){
        return "upload";
    }

    @RequestMapping("/upload1")
    @ResponseBody
    public void upload1(String filename,@RequestParam("file") MultipartFile multipartFile) throws IOException {
        System.out.println(filename);
//        System.out.println(multipartFile);
        String name = multipartFile.getOriginalFilename();
        System.out.println(name);
        multipartFile.transferTo(new java.io.File("C:\\java\\test\\"+name));
    }

    @RequestMapping("/upload2")
    @ResponseBody
    public void upload2(MultipartFile[] files) throws IOException {
        for(MultipartFile file : files) {
            String name = file.getOriginalFilename();
            System.out.println(file.getName());
            file.transferTo(new java.io.File("C:\\java\\test\\"+name));
        }
    }
}
