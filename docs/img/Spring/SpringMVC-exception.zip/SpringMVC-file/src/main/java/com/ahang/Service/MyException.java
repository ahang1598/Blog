package com.ahang.Service;

/**
 * @author ahang
 * @date 2021/12/25 16:58
 */
public class MyException extends Exception {
}
