package com.ahang.Service;

import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 * @author ahang
 * @date 2021/12/22 16:56
 */
@Service("exceptionDemo")
public class ExceptionDemoImpl implements ExceptionDemo {
    @Override
    public void show1() {
        System.out.println("类型转换异常");
        String str = "abc_";
        int num = Integer.parseInt(str);
    }

    @Override
    public void show2() {
        System.out.println("除0异常");
        int num = 1/0;
    }

    @Override
    public void show3() throws FileNotFoundException {
        System.out.println("文件读取异常");
        InputStream is = new FileInputStream("c:\\xx");
    }

    @Override
    public void show4() {
        System.out.println("空指针异常");
        String str = null;
        System.out.println(str.length());
    }



    @Override
    public void show5() throws MyException {
        System.out.println("自定义异常");
        throw new MyException();
    }
}
