package com.ahang.Service;

import java.io.FileNotFoundException;

/**
 * @author ahang
 * @date 2021/12/22 16:55
 */
public interface ExceptionDemo {
    public void show1();
    public void show2();
    public void show3() throws FileNotFoundException;
    public void show4();
    public void show5() throws MyException;
}
