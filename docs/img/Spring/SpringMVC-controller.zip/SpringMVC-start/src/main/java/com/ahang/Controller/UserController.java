package com.ahang.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author ahang
 * @date 2021/12/24 11:23
 */
@Controller("user")
@RequestMapping("/User")
public class UserController {

    @RequestMapping("user1")
    public String user1() {
        System.out.println("user1 running...");
//        return "/WEB-INF/jsp/success.jsp";
        return "success";
    }
}
