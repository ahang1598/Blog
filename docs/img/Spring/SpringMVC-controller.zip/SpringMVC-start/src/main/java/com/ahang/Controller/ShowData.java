package com.ahang.Controller;

import com.ahang.Entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author ahang
 * @date 2021/12/25 11:04
 */
@Controller
public class ShowData {

    @RequestMapping("showData1")
    @ResponseBody
    public String showData1() {
        return "hello";
    }

    @RequestMapping("showData2")
    public void showData2(HttpServletResponse response) throws IOException {
        response.getWriter().println("hello");
    }

    @RequestMapping("showJson")
    @ResponseBody
    public User showJson() {
        User user = new User("haha", 22);
        return user;
    }
}
