package com.ahang.Controller;

import com.ahang.Entity.User;
import com.ahang.Entity.UserList;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.List;

/**
 * @author ahang
 * @date 2021/12/25 11:33
 */
@Controller
public class Send {

    @RequestMapping("/send1")
    @ResponseBody
    public void send1(String username, int age) {
        System.out.println(username + " - " + age);
    }

    @RequestMapping("/send2")
    @ResponseBody
    public void send2(User user) {
        System.out.println(user.getUsername() + " - " + user.getAge());
    }

    @RequestMapping("/send3")
    @ResponseBody
    public void send3(String[] strs) {
        System.out.println(Arrays.toString(strs));
    }

    @RequestMapping("/sendJsp")
    public String sendJsp(){
        return "send";
    }

    @RequestMapping("/send4")
    @ResponseBody
    public void send4(UserList userList) {
        userList.show();
    }

    @RequestMapping("/send5")
    @ResponseBody
    // 请求参数非username而是name, http://localhost:8080/send5?name=haha
    public void send5(@RequestParam(value = "name", defaultValue = "null", required = true)
                        String username) {
        System.out.println(username);
    }

    @RequestMapping("/send6/{name}")
    @ResponseBody
    public void send6(@PathVariable(value = "name") String username) {
        System.out.println(username);
    }


    @RequestMapping("/send7")
    @ResponseBody
    public void send7(HttpServletRequest req, HttpServletResponse resp, HttpSession hs) {
        System.out.println(req);
        System.out.println(resp);
        System.out.println(hs);
    }

    @RequestMapping("/send8")
    @ResponseBody
    public void send8(@RequestHeader(value = "User-Agent", required = false) String agent) {
        System.out.println(agent);
    }

    @RequestMapping("/send9")
    @ResponseBody
    public void send9(@CookieValue(value = "JSESSIONID") String cookies) {
        System.out.println(cookies);
    }



}
