package com.ahang.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * @author ahang
 * @date 2021/12/25 10:12
 */
@Controller
public class Show {

    @RequestMapping("/show1")
    public ModelAndView show1(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("info","hello");
        modelAndView.setViewName("show");
        System.out.println("show run..");
        return modelAndView;
    }

    @RequestMapping("/show2")
    public ModelAndView show2(ModelAndView modelAndView){
        modelAndView.addObject("info", "hello");
        modelAndView.setViewName("show");
        return modelAndView;
    }

    @RequestMapping("/show3")
    public String show3(Model model) {
        model.addAttribute("info", "hello");
        return "show";
    }

    @RequestMapping("/show4")
    public String show4(HttpServletRequest request) {
        request.setAttribute("info", "hello");
        return "show";
    }
}
