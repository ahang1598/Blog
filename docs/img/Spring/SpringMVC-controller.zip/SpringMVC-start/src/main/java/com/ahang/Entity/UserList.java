package com.ahang.Entity;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * @author ahang
 * @date 2021/12/25 11:36
 */
public class UserList {
    private List<User> list;

    public UserList(List<User> list) {
        this.list = list;
    }

    public List<User> getList() {
        return list;
    }

    public void setList(List<User> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "UserList{" +
                "list=" + Arrays.asList(list.stream().toArray()) +
                '}';
    }

    public void show(){
        for(User e: list){
            System.out.println(e.getUsername() + "--" + e.getAge());
        }
    }
}
