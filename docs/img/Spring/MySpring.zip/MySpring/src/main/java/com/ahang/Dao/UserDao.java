package com.ahang.Dao;

/**
 * @author ahang
 * @date 2021/12/22 21:31
 */
public interface UserDao {
    public void run();
}
