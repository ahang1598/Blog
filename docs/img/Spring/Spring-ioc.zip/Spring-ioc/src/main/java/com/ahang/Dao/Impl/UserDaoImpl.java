package com.ahang.Dao.Impl;

import com.ahang.Dao.UserDao;

/**
 * @author ahang
 * @date 2021/12/23 8:53
 */
public class UserDaoImpl implements UserDao {
    @Override
    public void run() {
        System.out.println("running..");
    }
}
