package com.ahang.Dao;

/**
 * @author ahang
 * @date 2021/12/23 10:45
 */
public interface StudentDao {
    public void study();
}
