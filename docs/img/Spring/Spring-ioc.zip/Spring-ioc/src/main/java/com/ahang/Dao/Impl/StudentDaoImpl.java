package com.ahang.Dao.Impl;

import com.ahang.Dao.StudentDao;
import com.ahang.Entity.Student;

import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * @author ahang
 * @date 2021/12/23 10:46
 */
public class StudentDaoImpl implements StudentDao {

    private String name;
    private int age;

    private List<String> listStr;
    private List<Student> listStudent;
    private Map<String, Student> mapStudent;
    private Properties properties;

    public void setListStr(List<String> listStr) {
        this.listStr = listStr;
    }

    public void setListStudent(List<Student> listStudent) {
        this.listStudent = listStudent;
    }

    public void setMapStudent(Map<String, Student> mapStudent) {
        this.mapStudent = mapStudent;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public void study() {
        System.out.println(name + " - " + age);
        System.out.println(listStr);
        for(Student s : listStudent){
            System.out.println(s);
        }
        for(String s : mapStudent.keySet()){
            System.out.println(s + " - " + mapStudent.get(s));
        }

        System.out.println(properties);
    }


}
