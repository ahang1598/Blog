package com.ahang;

import com.ahang.Dao.UserDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author ahang
 * @date 2021/12/24 9:00
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class XmlTest {
    @Autowired
    UserDao userDao;

    @Test
    public void test() {
        userDao.run();
//        check before run
//        around check before run
//        running...
//        around check after run
//        after return then check
//        check after run anyway
    }

}
