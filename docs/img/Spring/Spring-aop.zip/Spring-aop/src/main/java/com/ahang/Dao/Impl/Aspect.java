package com.ahang.Dao.Impl;

import org.aspectj.lang.ProceedingJoinPoint;

/**
 * @author ahang
 * @date 2021/12/24 8:49
 */
public class Aspect {

    public void before(){
        System.out.println("check before run");
    }

    public void after() {
        System.out.println("check after run anyway");
    }

    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("around check before run");
        Object proceed = pjp.proceed();
        System.out.println("around check after run");
        return proceed;
    }

    public void afterThrow() {
        System.out.println("after exception check");
    }

    public void afterReturn() {
        System.out.println("after return then check");
    }
}
