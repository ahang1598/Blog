package com.ahang.Dao.Impl;

import com.ahang.Dao.UserDao;

/**
 * @author ahang
 * @date 2021/12/24 8:48
 */
public class UserDaoImpl implements UserDao {
    public void run() {
        System.out.println("running...");
    }
}
