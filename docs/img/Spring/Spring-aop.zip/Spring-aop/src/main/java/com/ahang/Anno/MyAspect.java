package com.ahang.Anno;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

/**
 * @author ahang
 * @date 2021/12/24 10:23
 */
@Component("aspect")
@Aspect
public class MyAspect {
    @Before("execution( * com.ahang.Anno.*.* (..) )")
    public void before() {
        System.out.println("check before run");
    }

    @Pointcut("execution( * com.ahang.Anno.Target.* (..) )")
    public void myPoint() {}

    @After("myPoint()")
    public void after() {
        System.out.println("check after run anyway");
    }

    @Around("myPoint()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("around check before run");
        Object proceed = pjp.proceed();
        System.out.println("around check after run");
        return proceed;
    }

    @AfterThrowing("myPoint()")
    public void afterThrow() {
        System.out.println("after exception check");
    }

    @AfterReturning("myPoint()")
    public void afterReturn() {
        System.out.println("after return then check");
    }

}
