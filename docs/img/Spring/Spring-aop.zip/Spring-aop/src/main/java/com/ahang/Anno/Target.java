package com.ahang.Anno;

import org.springframework.stereotype.Component;

/**
 * @author ahang
 * @date 2021/12/24 10:19
 */
@Component("target")
public class Target {
    public void run() {
        System.out.println("running...");
    }
}
