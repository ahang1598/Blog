package com.ahang.Dao;

/**
 * @author ahang
 * @date 2021/12/24 8:47
 */
public interface UserDao {
    public void run();
}
