package com.ahang.test;

import com.ahang.Config.applicationContext;
import com.ahang.Service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author ahang
 * @date 2021/12/23 23:29
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {applicationContext.class})
public class TestJunit {
    @Autowired
    private UserService userService;

    @Test
    public void test(){
        userService.run();
    }
}
