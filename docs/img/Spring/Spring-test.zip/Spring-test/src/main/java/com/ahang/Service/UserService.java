package com.ahang.Service;

/**
 * @author ahang
 * @date 2021/12/23 23:24
 */
public interface UserService {
    public void run();
}
