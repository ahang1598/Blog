package com.ahang.Config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author ahang
 * @date 2021/12/23 23:26
 */
@Configuration
@ComponentScan("com.ahang")
public class applicationContext {

}
