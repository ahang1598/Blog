package com.ahang.Service.Impl;

import com.ahang.Service.UserService;
import org.springframework.stereotype.Service;

/**
 * @author ahang
 * @date 2021/12/23 23:24
 */
@Service("userService")
public class UserServiceImpl implements UserService {

    @Override
    public void run() {
        System.out.println("running...");
    }
}
